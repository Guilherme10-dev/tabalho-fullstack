﻿using MySql.Data.MySqlClient;

namespace SistemaFullStackApp
{
    public static class ConexaoMySQL
    {
        private static string strConexao = "Server=localhost;Port=3307;Database=FullStackDB;Uid=root;Pwd=;";
        public static MySqlConnection ObterConexao()
        {
            return new MySqlConnection(strConexao);
        }
        


    }
}
